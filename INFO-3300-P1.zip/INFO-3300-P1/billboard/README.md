# Billboard scraping and data processing scripts

Note: `1_fetch.py` requires billboard.py to be installed. Install with pip. See writup in parent directory for more info.

Data dump required by these scripts has been omitted. It's around 60mb total. We hid the CMS upload limit.

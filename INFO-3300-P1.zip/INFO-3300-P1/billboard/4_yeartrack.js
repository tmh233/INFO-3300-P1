"use strict";
/* global require, console, process */

/**
 * Billboard Array -> Year in review array
 *
 * [ { year:
 *     songs: [
 *       { artist:
 *         title: 
 *         weeks:
         }
         ...
 *     ]
 *   }
 *   ...
 * ]
 */

var BucketObject = require('./util.js').BucketObject;

////////////////// //////////////////

require('./data/billboard.json')

// Put dates in songs
.map_songs(function (song, chart) {
  return {
    spotifyLink : song.spotifyLink,
    artist: song.artist,
    title: song.title,
    year: new Date(chart.date).getFullYear()
  };
})

// Make it an array of songs
.flatten_charts()

// Bucketize into song + year
.reduce(function (acc, song) {
  var id = song.title + '%%%' + song.artist + '%%%' + song.year;
  if (!acc[id]) acc[id] = [];
  acc[id].push(song);
  return acc;
}, new BucketObject())

.map(function (entry_array) {
  return {
    title : entry_array[0].title,
    artist: entry_array[0].artist,
    spotifyLink: entry_array[0].spotifyLink,
    weeks: entry_array.length,
    year: entry_array[0].year
  };
})

// [song + year] -> [{year, songs}]
.reduce(function (acc, song) {
  var id = song.year;
  delete song.year;
  if (!acc[id]) acc[id] = [];
  acc[id].push(song);
  return acc;
}, new BucketObject())

// Each bucket -> Son in an array
.map(function (year_array, year) {
  return {
    year : year,
    songs: year_array
  };
})

// .then(function (arr) {
//   console.log(arr[0]);
//   process.exit(0);
// });

.then(function(arr) {
  require('fs').writeFileSync('./data/yeartrack.json', JSON.stringify(arr));
});






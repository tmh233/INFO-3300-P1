"use strict";
/* global require, console, process */

/**
 * Billboard Array -> Song rank track array.
 *
 * [ { title:       + spotifyLink:
 *     artist:
 *     ranks: [ {
 *         rank:
 *         date:
 *       }
 *       ...
 *     ]
 *   }
 *   ...
 * ]
 */

var BucketObject = require('./util.js').BucketObject;

////////////////// //////////////////

require('./data/billboard.json')

// Put dates in songs
.map_songs(function (song, chart) {
  return {
    spotifyLink : song.spotifyLink,
    artist: song.artist,
    title: song.title,
    rank: song.rank,
    date: chart.date
  };
})

// Make it an array of songs
.flatten_charts()

// Bucketize based on song title + artist
.reduce(function (acc, song) {
  var id = song.title + '%%%' + song.artist;
  if (!acc[id]) acc[id] = [];
  acc[id].push(song);
  return acc;
}, new BucketObject())

// Each bucket -> Song in an array
.map(function (entry_array) {
  return {
    title : entry_array[0].title,
    artist: entry_array[0].artist,
    spotifyLink: entry_array[0].spotifyLink,
    ranks: entry_array
      .map(function (entry) {
        return {
          rank: entry.rank,
          date: new Date(entry.date)
        };
      })
  };
})

// .then(function (arr) {
//   console.log(arr[0]);
//   process.exit(0);
// });

.then(function(arr) {
  require('fs').writeFileSync('./data/songtrack.json', JSON.stringify(arr));
});






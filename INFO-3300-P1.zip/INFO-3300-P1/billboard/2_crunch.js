"use strict";
/* global require, console */

/**
 * Data dump -> Billboard Array
 *
 * [ { date:
 *     entries: [ {
 *       spotifyLink
 *       artist
 *       title
 *       peakPos
 *       change
 *       weeks
 *       rank
 *       lastPos
 *     } ]
 *   }
 * ...
 * ]
 */

var fs = require('fs');

Array.prototype.then = function(cb) {
  var res = cb(this);
  return (res === undefined) ? this : res;
};

Array.prototype.map_songs = function (cb) {
  return this.map(function (chart) {
    chart.entries = chart.entries.map(function (song) {
      return cb(song, chart);
    });
    return chart;
  });
};

Array.prototype.map_charts = Array.prototype.map;


// Get the files
fs.readdirSync('./data/dump').map(function (file) {
  try { return require('./data/dump/' + file); }
  catch (e) { console.log('lost', file); return null; }
})

// Filter any garbate (ie. .DS_store)
.filter(function (chart) { return !!chart; })


.map_charts(function (chart) {
                             // Unecessary because:
  delete chart.latest;       // only one will be latest, and we have .date
  delete chart.previousDate; // we have the whole array, can just see next one
  delete chart.name;         // we're only dealing with hot-100

  chart.date = new Date(chart.date);
  return chart;
})


.map_songs(function (song) {
  song.change = song.change = 'New' ? 'New' : parseInt(song.change);
  return song;
})

.then(function(arr) {
  fs.writeFileSync('./data/billboard.json', JSON.stringify(arr));
});



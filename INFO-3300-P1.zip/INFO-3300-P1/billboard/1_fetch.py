import billboard
import json
from time import sleep


# Uses billboard.py to 
# fetch all billboard data.
# Puts it all in ./dump/
chart = billboard.ChartData('hot-100', date=None, fetch=True)
while True:
    f = open("data/dump/" + chart.date + ".json","w")
    f.write(json.dumps(chart, default=lambda o: o.__dict__))
    print chart.date
    f.close()

    chart = billboard.ChartData('hot-100', chart.previousDate)
    
    if not chart.previousDate:
      break
    else:
      sleep(2) # try not to hammer Billboard.


"use strict";
/* global require, console, process */

/**
 * Billboard Array -> Artist rank track array.
 *
 * [ { artist:       + spotifyLink:
 *     ranks: [ [{
 *         rank:
 *         date:
 *       }], // each sub-array is a contigous ranking
 *       ...
 *     ]
 *   }
 *   ...
 * ]
 */

var BucketObject = require('./util.js').BucketObject;

////////////////// //////////////////

require('./data/billboard.json')

// Put dates in songs
.map_songs(function (song, chart) {
  return {
    spotifyLink : song.spotifyLink,
    artist: song.artist,
    title: song.title,
    rank: song.rank,
    date: chart.date
  };
})

// Make it an array of songs
.flatten_charts()

/**
 * Here:
{ spotifyLink: 'https://embed.spotify.com/?uri=spotify:track:33FPsMEl3UwpytDuyf9VYq',
  artist: 'Ricky Nelson',
  title: 'Poor Little Fool',
  rank: 1,
  date: '1958-08-09T00:00:00.000Z' }
 */

// Bucketize based on song artist %%% date
.reduce(function (acc, song) {
  var id = song.artist + '%%%' + song.date;
  if (!acc[id]) acc[id] = [];
  acc[id].push(song);
  return acc;
}, new BucketObject())

// Each bucket -> Artist + date in an array (w/ top_rank per date)
.map(function (entry_array) {
  return {
    artist: entry_array[0].artist,
    date: entry_array[0].date,
    rank: entry_array.sort(function (sa, sb) {
      return sa.rank - sb.rank;
    })[0].rank

    // spotifyLink: entry_array[0].spotifyLink,
    // ranks: entry_array
    //   .map(function (entry) {
    //     return {
    //       rank: entry.rank,
    //       // song: entry.title,
    //       date: new Date(entry.date)
    //     };
    //   })
  };
})

/* Here:

{ artist: 'Ricky Nelson',
  date: '1958-08-09T00:00:00.000Z',
  rank: 1 }

 */


// Bucketize based on song artist
.reduce(function (acc, song) {
  var id = song.artist;
  if (!acc[id]) acc[id] = [];
  acc[id].push(song);
  return acc;
}, new BucketObject())

// Each bucket -> Artist in an array (w/ top_rank per date)
.map(function (entry_array) {
  return {
    artist: entry_array[0].artist,
    weeks: entry_array.length,
    top: entry_array.reduce(function (acc, e) {
      return (e.rank < acc) ? e.rank : acc;
    }, 100),
    ranks: entry_array
      .map(function (e) {
        return {
          rank: e.rank,
          date: new Date(e.date)
        };
      })
      // Sort ranks.
      .sort(function (e1, e2) {
        return e1.date - e2.date;
      })

      // Reduce to continous groups
      .reduce(function (acc, e) {
        if (acc === null) return [[e]];
        var curr_group = acc[acc.length-1];
        var date_diff = curr_group[curr_group.length-1].date - e.date;
        if (date_diff > -604800001) {
          curr_group.push(e);
        } else {
          acc.push([e]);
        }
        return acc;
      }, null)
  };
})

.sort(function (a1, a2) {
  return a2.weeks - a1.weeks; // decending order
})

.then(function(arr) {
  require('fs').writeFileSync('./data/artisttrack.json', JSON.stringify(arr));
});






"use strict";
/* global module, console, require */

Array.prototype.then = function(cb) {
  var res = cb(this);
  return (res === undefined) ? this : res;
};

Array.prototype.map_songs = function (cb) {
  return this.map(function (chart) {
    chart.entries = chart.entries.map(function (song) {
      return cb(song, chart);
    });
    return chart;
  });
};

Array.prototype.map_charts = Array.prototype.map;


Array.prototype.flatten_charts = function() {
  return this.reduce(function (acc, x) {
    return acc.concat(x.entries);
  }, []);
};

function BucketObject () {}

BucketObject.prototype.map = function(cb) {
  var self = this;
  return Object.keys(this).map(function (key) {
    return cb(self[key], key);
  });
};

BucketObject.prototype.then = function(cb) {
  var res = cb(this);
  return (res === undefined) ? this : res;
};


module.exports = {
  BucketObject : BucketObject
};


if (require.main === module) {
  var bo = new BucketObject();
  bo['one'] = 1;
  bo['two'] = 2;
  // console.log(bo);
  bo.map(function (num, key) {
    console.log(num, key);
  });
}
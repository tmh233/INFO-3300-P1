<html>
<head>
  <meta charset="UTF-8">
  <title></title>
  <link rel="stylesheet" href="css/kevin.css">
  <link rel="stylesheet" type="text/css" href="css/terryCSS.css">

</head>
<body>
  <!-- <div id="out1"></div> -->
  <h1>How big is the musical 1%?</h1>

  <!-- KEVIN'S CHART -->
  <div class="flexgraph">
    <div id="out2"></div>
    <div id="info2" class="info">
      <h3>Fewer songs/artists make big.</h3>
      <p>The billboard Hot-100 features 5200 different songs in a year. How many different songs "make it", however? The overal trend is ever less big-name-artists dominate the charts.</p>
      <p>On the left, 56 years of billboard data on unique song/artist counts per year.</p>
      <p id="out2key"></p>
      <h4>Note how...</h4>
      <ul>
        <li>... the 60s saw the most fluent charts. In '67, <span class="song">827</span> different songs made it. That's more than double the measly <span class="song">406</span> charted in 1994.</li>
        <li>... 1970 had <span class="artist">423</span> different top performers; last year it was only <span class="artist">346</span>.
        </li>
        <li>... the 90s were the decade of a few mainstream bangers. Only <span class="artist">291</span> different artists charted in '92; an all-time low.</li>
      </ul>
    </div>
  </div>

  <!-- TERRY'S CHART -->

          <?php include 'worldmap-template.php';?>


 
  <script src="https://cdnjs.cloudflare.com/ajax/libs/d3/3.5.16/d3.min.js"></script>
  <script src="https://raw.githubusercontent.com/bgrins/TinyColor/master/dist/tinycolor-min.js"></script>
  <script src="js/topojson.v1.min.js"></script>
<script src="http://d3js.org/d3.geo.projection.v0.min.js"></script>

  <script src="js/kevin.js"></script>
</body>
</html>